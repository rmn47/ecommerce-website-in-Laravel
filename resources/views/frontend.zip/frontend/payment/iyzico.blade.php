<html>
  <head>
    <title>IYZICO Payment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  </head>
  <body>
    <div id="iyzipay-checkout-form" class="popup"></div>

    {!! $content !!}
  </body>
</html>
